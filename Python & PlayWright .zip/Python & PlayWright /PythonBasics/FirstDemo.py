print("hello")

a = 3
print(a)

str = "hello world"
print(str)

a, b, c = 5, 7.8, "cool"
print(a, b, c)

print("{} {}".format("Value is", b))


