
str = "RahulShettyAcademy.com "
str1 = "consulting firm"
str3 = "RahulShetty"

print(str[1])
print(str[0:5])     # If you want substring in python

# string concetination
print(str+str1)

# check if str3 is present in str
print(str3 in str)

# slit string
print(str.split("."))

# tream string
str4 = "great   "
print(str4.strip())