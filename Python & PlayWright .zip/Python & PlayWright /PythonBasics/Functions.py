# In python, function is a group of related statements that perform a specific task.

def Greetme(name):
    print("good morning " + name)

def AddIntegers(a, b):
    return a+b

Greetme("Rahul shetty")
print(AddIntegers(3, 4))