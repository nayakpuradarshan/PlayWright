"""
in any programming language, function is a group of related
statements that performs a specific task.
"""

def GreetMe(name):
    print("inside the function " + name)


def addTwoNumbers(a, b):
    print(a + b)

GreetMe("Darshan Patel")
addTwoNumbers(10, 2)