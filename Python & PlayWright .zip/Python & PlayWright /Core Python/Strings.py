str = "RahulShettyAcademy.com"
str1 = "Consulting firm"
str3 = "RahulShetty"

print(str)
print(str[0:5])         # string slicing
print(str3 in str)      # check str3 is present in str or not

print(str)
split_str = str.split(".")
print(split_str)