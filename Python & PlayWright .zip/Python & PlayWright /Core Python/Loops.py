
"""
greeting = "Good Morning"

if greeting == "Good Morning":
    print("Hey, you're at right place")
    print("Second line!")
else:
    print("Hey, You're at wrong place")

print("\nNow, you're out of if else condition!")
"""

"""
age = 10

if age > 18:
    print(f"you can drive a car, as you're {age} now")
else:
    print(f"You can't drive a car, as you're just {age} now")
"""


"""
# sum of frist natiral numbers 1+2+3+4+5 = 15

numbers = [1, 2, 3, 4, 5, 1]
summation = 0

for i in numbers:
    summation += i

print("Summation value is:", summation)
"""

"""
# Print odd numbers till 100

for i in range(1, 101, 2):
    print(i, end=" ")
"""

# while loop

"""
it = 10

while it > 1:
    if it == 9:
        it = it - 1
        continue
    if it == 2:
        break
    print(it)

    it = it - 1

print("while loop execution is completed")
"""












